from spikingjelly.clock_driven.ann2snn.converter import Converter
from spikingjelly.clock_driven.ann2snn.utils import download_url